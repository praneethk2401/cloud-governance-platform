import boto3
import json
import os
from datetime import datetime

def lambda_handler(event, context):
    sns = boto3.client('sns', region_name='ap-south-2')
    
    print(f"Received event: {json.dumps(event, default=str)}")
    
    # Extract finding details from EventBridge event
    try:
        finding = event['detail']['findings'][0]
        finding_id       = finding['Id']
        finding_title    = finding['Title']
        severity         = finding['Severity']['Label']
        account_id       = finding['AwsAccountId']
        resources        = finding['Resources']
        generator_id     = finding.get('GeneratorId', '')
        
        print(f"Processing finding: {finding_title} | Severity: {severity}")
        
    except KeyError as e:
        print(f"Error parsing finding: {str(e)}")
        return {'statusCode': 400, 'body': 'Invalid finding format'}

    remediation_taken = False
    remediation_details = []

    # Loop through affected resources
    for resource in resources:
        resource_type = resource['Type']
        resource_id   = resource['Id']

        # Remediation 1 — Block public S3 buckets
        if resource_type == 'AwsS3Bucket':
            try:
                s3          = boto3.client('s3', region_name='ap-south-2')
                bucket_name = resource_id.split(':::')[-1]
                
                s3.put_public_access_block(
                    Bucket=bucket_name,
                    PublicAccessBlockConfiguration={
                        'BlockPublicAcls'      : True,
                        'IgnorePublicAcls'     : True,
                        'BlockPublicPolicy'    : True,
                        'RestrictPublicBuckets': True
                    }
                )
                msg = f"REMEDIATED: Blocked public access on S3 bucket {bucket_name}"
                print(msg)
                remediation_details.append(msg)
                remediation_taken = True
                
            except Exception as e:
                print(f"Failed to remediate S3 bucket: {str(e)}")

        # Remediation 2 — Remove unrestricted security group rules
        elif resource_type == 'AwsEc2SecurityGroup':
            try:
                ec2   = boto3.client('ec2', region_name='ap-south-2')
                sg_id = resource_id.split('/')[-1]
                
                sg = ec2.describe_security_groups(GroupIds=[sg_id])
                
                for permission in sg['SecurityGroups'][0]['IpPermissions']:
                    for ip_range in permission.get('IpRanges', []):
                        if ip_range['CidrIp'] == '0.0.0.0/0':
                            # Only remove unrestricted rules on sensitive ports
                            from_port = permission.get('FromPort', 0)
                            if from_port in [22, 3389, 1433, 3306, 5432]:
                                ec2.revoke_security_group_ingress(
                                    GroupId      =sg_id,
                                    IpPermissions=[permission]
                                )
                                msg = f"REMEDIATED: Removed unrestricted port {from_port} rule from SG {sg_id}"
                                print(msg)
                                remediation_details.append(msg)
                                remediation_taken = True
                                
            except Exception as e:
                print(f"Failed to remediate security group: {str(e)}")

        # Remediation 3 — Enable S3 bucket versioning
        elif 'S3.14' in generator_id:
            try:
                s3          = boto3.client('s3', region_name='ap-south-2')
                bucket_name = resource_id.split(':::')[-1]
                
                s3.put_bucket_versioning(
                    Bucket               =bucket_name,
                    VersioningConfiguration={'Status': 'Enabled'}
                )
                msg = f"REMEDIATED: Enabled versioning on S3 bucket {bucket_name}"
                print(msg)
                remediation_details.append(msg)
                remediation_taken = True
                
            except Exception as e:
                print(f"Failed to enable S3 versioning: {str(e)}")

    # If we couldn't auto-remediate — escalate via SNS
    if not remediation_taken:
        try:
            escalation_message = f"""
MANUAL ACTION REQUIRED — Security Finding

Title    : {finding_title}
Severity : {severity}
Account  : {account_id}
Time     : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Resources Affected:
{json.dumps(resources, indent=2, default=str)}

This finding could not be auto-remediated.
Please review and take manual action.
            """
            
            sns.publish(
                TopicArn=os.environ['SNS_TOPIC_ARN'],
                Subject =f"MANUAL ACTION REQUIRED: {severity} Security Finding",
                Message =escalation_message
            )
            print(f"ESCALATED: SNS alert sent for finding {finding_id}")
            
        except Exception as e:
            print(f"Failed to send SNS escalation: {str(e)}")

    return {
        'statusCode'         : 200,
        'remediation_taken'  : remediation_taken,
        'remediation_details': remediation_details,
        'finding_id'         : finding_id
    }